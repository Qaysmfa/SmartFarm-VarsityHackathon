<?php
// Database connection
$servername = "localhost";
$username = "root";  // Replace with your MySQL username
$password = "";  // Replace with your MySQL password
$dbname = "weatherdb";  // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch crop health data
$sql = "SELECT latitude, longitude, health_value, field_name FROM crop_health";
$result = $conn->query($sql);

$heatmap_data = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Normalize health value (0-1) and round lat/lng to 3 decimal places
        $heatmap_data[] = [
            "lat" => round((float)$row["latitude"], 3),
            "lng" => round((float)$row["longitude"], 3),
            "value" => min(max($row["health_value"] / 100, 0), 1),  // ensure it's in range 0�1
            "name" => $row["field_name"]
        ];
    }
} else {
    echo json_encode([]);
    exit;
}

$conn->close();

// Return the data as JSON
header('Content-Type: application/json');
echo json_encode($heatmap_data);
?>
