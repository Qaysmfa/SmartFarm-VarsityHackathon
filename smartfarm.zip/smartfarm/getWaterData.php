<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "weatherdb"; // Replace with your actual DB name

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch water consumption data
$sql = "SELECT month, water_consumption_liters FROM water_consumption_analysis ORDER BY FIELD(month, 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data);

$conn->close();
?>
