<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "weatherdb"; // Replace with your actual DB name

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch soil fertility data (assuming the table name is 'soil_quality')
$sql = "SELECT month, soil_fertility_level FROM soil_fertility_levels ORDER BY FIELD(month, 'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data);

$conn->close();
?>
