﻿<?php
include 'db_connection.php'; // if you use one

if (!isset($city)) {
    $city = "Penang"; // Default city if not set
}

$sql = "SELECT city, temperature, description, humidity, wind_speed, precipitation, forecast_date 
    FROM weather_forecast 
    WHERE city = '$city' 
    AND forecast_date >= CURDATE() 
    GROUP BY DATE(forecast_date) 
    ORDER BY forecast_date ASC
    LIMIT 5;";

$result = $conn->query($sql);

echo "<div class='weather-container'>"; // Create a container for the weather data

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Display weather data inside weather cards
        echo "<div class='weather-card'>
                <div class='weather-date'>" . date('D, M d, Y', strtotime($row['forecast_date'])) . "</div>
                <div class='weather-temp'>" . $row['temperature'] . "°C</div>
                <div class='weather-description'>" . ucfirst($row['description']) . "</div>
                <div class='weather-details'>
                    <p><strong>Humidity:</strong> " . $row['humidity'] . "%</p>
                    <p><strong>Wind Speed:</strong> " . $row['wind_speed'] . " km/h</p>
                    <p><strong>Precipitation:</strong> " . $row['precipitation'] . " mm</p>
                </div>
            </div>";
    }
    echo "</div>"; // Closing the weather container
} else {
    echo "<p>No weather data available.</p>";
}

$conn->close();
?>
