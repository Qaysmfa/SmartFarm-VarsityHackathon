﻿const translations = {
    en: {
        welcome: "Good Morning, Farmer Raju!",
        status: "Here’s your farm’s status at a glance.",
        alertLegend: "🔔 Alert Status Legend",
        greenStatus: "🟢 Green: All Clear / No Issues",
        redStatus: "🔴 Red: Immediate Action Required",
        weatherForecast: "🌤 Weather Forecast",
        cropHealth: "🌱 Crop Health Heatmap",
        soilMoisture: "💧 Soil Moisture",
        pestAlert: "🐛 Pest Alert",
        viewRecommendations: "📋 View Action Recommendations",
        footerLine1: "Secure & farmer-friendly platform.",
        footerLine2: "Support: 📞 1800-XXX-XXXX | 💬 Chat Support Available"
    },
    ms: {
        welcome: "Selamat Pagi, Petani Raju!",
        status: "Berikut ialah status ladang anda secara ringkas.",
        alertLegend: "🔔 Legenda Status Amaran",
        greenStatus: "🟢 Hijau: Tiada Masalah",
        redStatus: "🔴 Merah: Tindakan Segera Diperlukan",
        weatherForecast: "🌤 Ramalan Cuaca",
        cropHealth: "🌱 Peta Panas Kesihatan Tanaman",
        soilMoisture: "💧 Kelembapan Tanah",
        pestAlert: "🐛 Amaran Perosak",
        viewRecommendations: "📋 Lihat Cadangan Tindakan",
        footerLine1: "Platform selamat & mesra petani.",
        footerLine2: "Sokongan: 📞 1800-XXX-XXXX | 💬 Sokongan Chat Tersedia"
    },
    ta: {
        welcome: "காலை வணக்கம், விவசாயி ராஜு!",
        status: "உங்கள் பண்ணையின் நிலையை விரைவாக காண்க.",
        alertLegend: "🔔 எச்சரிக்கை நிலை விளக்கம்",
        greenStatus: "🟢 பச்சை: அனைத்தும் சரியாக உள்ளது",
        redStatus: "🔴 சிவப்பு: உடனடி நடவடிக்கை தேவை",
        weatherForecast: "🌤 வானிலை கணிப்பு",
        cropHealth: "🌱 பயிர் ஆரோக்கிய ஹீட்மாப்",
        soilMoisture: "💧 மண் ஈரப்பதம்",
        pestAlert: "🐛 பூச்சி எச்சரிக்கை",
        viewRecommendations: "📋 பரிந்துரைகளை காண்க",
        footerLine1: "பாதுகாப்பான மற்றும் விவசாயிகளுக்கேற்ப வடிவமைக்கப்பட்ட தளம்.",
        footerLine2: "உதவி: 📞 1800-XXX-XXXX | 💬 உரையாடல் ஆதரவு உள்ளது"
    }
};


function setLanguage(lang) {
    const t = translations[lang];

    document.getElementById("welcomeMsg").innerText = t.welcome;
    document.getElementById("statusMsg").innerText = t.status;
    document.getElementById("alertLegend").innerText = t.alertLegend;
    document.getElementById("greenStatus").innerText = t.greenStatus;
    document.getElementById("redStatus").innerText = t.redStatus;
    document.getElementById("weatherForecast").innerText = t.weatherForecast;
    document.getElementById("cropHealth").innerText = t.cropHealth;
    document.getElementById("soilMoisture").innerText = t.soilMoisture;
    document.getElementById("pestAlert").innerText = t.pestAlert;
    document.getElementById("viewRecommendations").innerText = t.viewRecommendations;
    document.getElementById("footerLine1").innerText = t.footerLine1;
    document.getElementById("footerLine2").innerText = t.footerLine2;
}
