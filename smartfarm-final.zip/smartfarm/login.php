﻿<?php
$servername = "localhost";
$username = "root"; // default XAMPP username
$password = ""; // default XAMPP password (empty)
$dbname = "smartfarm"; // replace with your DB name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get POST values
$user = $_POST['username'] ?? '';
$pass = $_POST['password'] ?? '';

// Prevent SQL injection
$user = $conn->real_escape_string($user);
$pass = $conn->real_escape_string($pass);

// Check credentials
$sql = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";
$result = $conn->query($sql);

if ($result && $result->num_rows === 1) {
  // Login successful, redirect to Home Page
  header("Location: Home%20Page.php");  // Note: spaces in URLs need to be encoded as "%20"
  exit();  // Ensure no further code is executed after the redirect
} else {
  echo "Invalid username or password.";
}

$conn->close();
?>
