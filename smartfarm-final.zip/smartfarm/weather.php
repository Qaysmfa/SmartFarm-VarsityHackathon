<?php
// Database connection
$host = "localhost";
$dbname = "weatherdb"; // Database name
$username = "root"; // Your DB username
$password = ""; // Your DB password

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// OpenWeatherMap API key and endpoint
$apiKey = "483d42d0ded5f8b6374ccea5ae3e3934"; // Your API key
$city = "Penang"; // Your city
$url = "https://api.openweathermap.org/data/2.5/forecast?q=$city&appid=$apiKey&units=metric"; // 5-day forecast API

// Fetch data from API
$response = file_get_contents($url);
$data = json_decode($response, true);

// Check if API returned valid data
if (!$response || !$data) {
    echo "Error fetching weather data.";
    exit;
}

// Iterate over the forecast data (we'll store data for the next 5 days)
$forecastedDates = [];
foreach ($data['list'] as $forecast) {
    // Extract weather data for each forecast entry
    $temperature = $forecast['main']['temp'];
    $description = $forecast['weather'][0]['description'];
    $humidity = $forecast['main']['humidity'];
    $wind_speed = $forecast['wind']['speed'];
    $precipitation = $forecast['rain']['3h'] ?? 0; // Precipitation for 3 hours, if available
    $forecast_date = date('Y-m-d H:i:s', $forecast['dt']); // Include the time in the format

    // Only insert the forecast once per day (based on the date)
    $date = date('Y-m-d', strtotime($forecast_date));

    if (!in_array($date, $forecastedDates)) {
        // Prepare SQL query to insert the weather data into the database
        $sql = "INSERT INTO weather_forecast (city, temperature, description, humidity, wind_speed, precipitation, forecast_date) 
                VALUES ('$city', $temperature, '$description', $humidity, $wind_speed, $precipitation, '$forecast_date')";

        if ($conn->query($sql) !== TRUE) {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $forecastedDates[] = $date; // Mark the date as processed
    }
}

echo "Weather data has been successfully updated in the database.";

// Fetch and display weather data from database
$sql = "SELECT * FROM weather_forecast WHERE city = '$city' ORDER BY forecast_date ASC LIMIT 5";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h1>5-Day Weather Forecast for $city</h1>";
    echo "<table border='1'>
            <tr>
                <th>Date</th>
                <th>Temperature (�C)</th>
                <th>Weather</th>
                <th>Humidity (%)</th>
                <th>Wind Speed (km/h)</th>
                <th>Precipitation (mm)</th>
            </tr>";

    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . date('D, M d, Y', strtotime($row['forecast_date'])) . "</td>
                <td>" . $row['temperature'] . "</td>
                <td>" . $row['description'] . "</td>
                <td>" . $row['humidity'] . "</td>
                <td>" . $row['wind_speed'] . "</td>
                <td>" . $row['precipitation'] . "</td>
            </tr>";
    }

    echo "</table>";
} else {
    echo "No weather data available.";
}

// Close database connection
$conn->close();
?>
