<?php
// getSoilMoistureData.php

header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "weatherdb");

if ($conn->connect_error) {
  die(json_encode(['error' => 'Database connection failed']));
}

$sql = "SELECT field_name, soil_moisture FROM crop_health";
$result = $conn->query($sql);

$data = [];

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $data[] = [
      'field' => $row['field_name'],
      'moisture' => $row['soil_moisture']
    ];
  }
}

$conn->close();

echo json_encode($data);
?>
