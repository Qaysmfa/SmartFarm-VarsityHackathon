<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "weatherdb";  // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get pest control data for all levels (safe, moderate, critical)
$sql = "SELECT month, safe_level, moderate_level, critical_level FROM pest_infestation_levels ORDER BY month ASC";
$result = $conn->query($sql);

$data = [];
if ($result->num_rows > 0) {
    // Fetch data
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Return data as JSON
echo json_encode($data);

// Close the connection
$conn->close();
?>
