<?php
$host = 'localhost'; // or your DB host
$db = 'weatherdb';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT field_name, pest_infestation_rate FROM crop_health";
$result = $conn->query($sql);

$pestData = [];

while($row = $result->fetch_assoc()) {
  $pestData[] = $row;
}

echo json_encode($pestData);

$conn->close();
?>
