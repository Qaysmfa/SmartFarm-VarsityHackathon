﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SmartFarm Dashboard</title>
    <link rel="shortcut icon" href="logo.png" />
    <link rel="stylesheet" href="styles.css" />

    <!-- Leaflet core -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>

    <!-- Leaflet heat plugin -->
    <script src="leaflet-heat.js"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="lang.js"></script>


</head>

<body>

  <!-- Header -->
  <header class="dashboard-header">
    <div class="logo">🌿 <strong>SmartFarm</strong></div>
    <div class="header-options">
      <select onchange="setLanguage(this.value)">
  <option value="en">🌐 English</option>
  <option value="ms">🇲🇾 Bahasa Melayu</option>
  <option value="ta">🇮🇳 தமிழ்</option>
</select>
      <span class="profile-name">Hello, Farmer Raju 👨‍🌾</span>
    </div>
  </header>

  <!-- Top Navigation -->
  <nav class="top-nav">
    <a class="nav-item active" href="Home Page.html">🏠 Home</a>
    <a class="nav-item" href="Farm Details Page.html">🌾 Farm Details</a>
    <a class="nav-item" href="Learning Zone Page.html">📚 Learning Zone</a>
  </nav>

  <!-- Main Dashboard -->
  <main class="dashboard-main">

    <!-- Welcome Message -->
    <section class="welcome-message card">
      <h2 id="welcomeMsg">Good Morning, Farmer Raju!</h2>
      <p id="statusMsg">Here’s your farm’s status at a glance.</p>
    </section>

    <!-- Alert Legend -->
    <section class="legend-box card">
      <h3 id="alertLegend">🔔 Alert Status Legend</h3>
      <ul>
        <li id="greenStatus">🟢 <strong>Green:</strong> All Clear / No Issues</li>
        <li id="redStatus">🔴 <strong>Red:</strong> Immediate Action Required</li>
      </ul>
    </section>

    <!-- Snapshot Cards -->
    <div class="card snapshot-card">
      <h3 id="weatherForecast">🌤 Weather Forecast</h3>
      <?php include 'weatherdashboard.php'; ?>
    </div>

<!-- Crop Health Heatmap -->
<div class="card snapshot-card status-green">
  <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: nowrap;">
    <h3 id="cropHealth">🌱 Crop Health Heatmap</h3>

        <!-- 🔴 Popup warning - hidden by default -->
    <div id="crop-health-warning" class="popup-warning" style="display: none;">
      🔴 Low crop health detected in one or more fields!
    </div>

    <!-- Legend placed to the right of heading -->
    <div id="heatmap-legend" style="margin-left: 20px; padding: 8px 12px; border-radius: 8px; background: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 280px; font-size: 15px;">
      <div style="margin-bottom: 4px; font-weight: bold;">🌡 Crop Health Legend</div>
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="flex: 1; height: 12px; background: linear-gradient(to right, red, orange, yellow, green, blue); border-radius: 6px;"></div>
        <div style="display: flex; flex-direction: column;">
          <span style="color: red;">Low</span>
          <span style="color: blue;">High</span>
        </div>
      </div>
    </div>
  </div>

  <div id="heatmap" style="width: 100%; height: 400px; border-radius: 10px; margin-top: 10px;"></div>
  <p>Interactive heatmap showing crop health across the fields.</p>
</div>



    <!-- Soil Moisture -->
    <div class="card-row">
  <!-- Soil Moisture -->
  <div class="card snapshot-card status-green half-card">
    <h3 id="soilMoisture">💧 Soil Moisture</h3>
      <div id="soil-moisture-warning" class="popup-warning" style="display: none;">
    🔴 Low soil moisture detected in one or more fields!
  </div>
    <canvas id="soilMoistureChart" width="400" height="200"></canvas>
  </div>

  <!-- Pest Alert -->
  <div class="card snapshot-card status-green half-card">
  <h3 id="pestAlert">🐛 Pest Alert</h3>
   <div style="display: flex; justify-content: center; align-items: center; height: 300px;">

  <canvas id="pestChart"></canvas>
</div>
  <div id="alertDetails" style="margin-top: 20px; color: black;">
  </div>
</div>


    <!-- Action Recommendations -->
    <div class="action-button-section">
      <a href="recommendation.html"><button class="action-button" id="viewRecommendations">📋 View Action Recommendations</button></a>
    </div>

  </main>

  <!-- Footer -->
  <footer class="dashboard-footer">
    <p id="footerLine1">Secure & farmer-friendly platform.</p>
    <p id="footerLine2">Support: 📞 1800-XXX-XXXX | 💬 Chat Support Available</p>
  </footer>

  <!-- Heatmap Script -->

<script>
fetch('getHeatmapData.php')
  .then(response => response.json())
  .then(data => {
    console.log('✅ Fetched heatmap data:', data);
    console.log('🧪 Sample point:', data[0]);

    const map = L.map('heatmap').setView([5.357, 100.272], 14);
    console.log('🗺️ Map initialized');

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    console.log('🧱 Tile layer added');

    const heatData = data.map(point => {
      const lat = parseFloat(point.lat);
      const lng = parseFloat(point.lng);
      const intensity = 1 - parseFloat(point.value);
      console.log(`🔥 Heat point: [${lat}, ${lng}, ${intensity}]`);
      return [lat, lng, intensity];
    });

    L.heatLayer(heatData, {
      radius: 30,
      blur: 20,
      maxZoom: 17,
      minOpacity: 0.5,
      gradient: {
        0.2: 'blue',
        0.4: 'lime',
        0.6: 'yellow',
        0.8: 'orange',
        1.0: 'red'
      }
    }).addTo(map);

    console.log('🌡️ Heatmap layer added');

    // Fix potential heatmap misalignment after render
    setTimeout(() => {
      map.invalidateSize();
      console.log('🧼 Map size invalidated (redraw triggered)');
    }, 300);

    // Check for low-health fields
    const lowHealthExists = data.some(point => point.value < 0.5);
    console.log(`🧪 Low health detected: ${lowHealthExists}`);

    if (lowHealthExists) {
      const cards = document.querySelectorAll('.snapshot-card');
      cards.forEach(card => {
        const h3 = card.querySelector('h3');
        if (h3 && h3.textContent.includes('Crop Health Heatmap')) {
          card.classList.add('low-health-border');

          const warning = card.querySelector('#crop-health-warning');
          if (warning) {
            warning.style.display = 'block';
            console.log('⚠️ Warning displayed for low health');
          }
        }
      });
    }

    // Add field name markers
    data.forEach(point => {
      L.marker([point.lat, point.lng], {
        icon: L.divIcon({
          className: 'field-label',
          html: `<strong>${point.name}</strong>`,
          iconSize: [100, 20],
          iconAnchor: [50, -10]
        })
      }).addTo(map);
      console.log(`📍 Marker added for: ${point.name}`);
    });

    console.log('✅ All markers and heatmap setup complete');
  })
  .catch(error => console.error('❌ Error fetching heatmap data:', error));
</script>






<script>
fetch('getSoilMoistureData.php')
  .then(response => response.json())
  .then(data => {
    const fields = data.map(d => d.field);
    const moisture = data.map(d => d.moisture);

    // ⚠️ Check if any moisture value is below 30%
    const lowMoistureExists = moisture.some(value => value < 30);
    if (lowMoistureExists) {
      const cards = document.querySelectorAll('.snapshot-card');
      cards.forEach(card => {
        const h3 = card.querySelector('h3');
        if (h3 && h3.textContent.includes('Soil Moisture')) {
          card.classList.add('low-health-border');

          const warning = card.querySelector('#soil-moisture-warning');
          if (warning) {
            warning.style.display = 'block';
          }
        }
      });
    }

    const ctx = document.getElementById('soilMoistureChart').getContext('2d');

    // Create gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, '#007bff');
    gradient.addColorStop(1, '#80bdff');

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: fields,
        datasets: [{
          label: 'Soil Moisture (%)',
          data: moisture,
          backgroundColor: gradient,
          borderColor: '#007bff',
          borderWidth: 1,
          borderRadius: 8,
          hoverBackgroundColor: '#3399ff'
        }]
      },
      options: {
        responsive: true,
        plugins: {
          title: {
            display: true,
            text: 'Per-Field Soil Moisture Levels',
            font: {
              size: 18
            }
          },
          tooltip: {
            backgroundColor: '#f8f9fa',
            titleColor: '#000',
            bodyColor: '#000',
            borderColor: '#007bff',
            borderWidth: 1
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: {
              color: '#e9ecef'
            },
            title: {
              display: true,
              text: 'Moisture (%)',
              font: {
                weight: 'bold'
              }
            }
          },
          x: {
            grid: {
              display: false
            }
          }
        },
        animation: {
          duration: 1000,
          easing: 'easeOutBounce'
        }
      }
    });
  })
  .catch(error => console.error('Error loading soil moisture data:', error));

</script>

<script>
fetch('getPestData.php')
  .then(response => response.json())
  .then(data => {
    const fields = data.map(d => d.field_name);
    const infestationRates = data.map(d => d.pest_infestation_rate);

    // ⚠️ Check if any pest infestation rate is above 20%
    const highPestInfestationExists = infestationRates.some(rate => rate > 20);
    if (highPestInfestationExists) {
      const cards = document.querySelectorAll('.snapshot-card');
      cards.forEach(card => {
        const h3 = card.querySelector('h3');
        if (h3 && h3.textContent.includes('🐛 Pest Alert')) {
          card.classList.add('low-health-border'); // Add red left border class

          const warning = card.querySelector('#pest-alert-warning');
          if (warning) {
            warning.style.display = 'block'; // Show warning if applicable
          }
        }
      });
    }

    const ctx = document.getElementById('pestChart').getContext('2d');

    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: fields,
        datasets: [{
          label: 'Pest Infestation Rate (%)',
          data: infestationRates,
          backgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56',
            '#4BC0C0',
            '#9966FF',
            '#FF9F40'
          ],
          borderColor: '#fff',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        plugins: {
          title: {
            display: true,
            text: 'Pest Infestation Distribution by Field',
            font: {
              size: 18
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `${context.label}: ${context.parsed}%`;
              }
            }
          }
        }
      }
    });

    // Pest Alert logic
    // Pest Alert logic
const alertDetails = document.getElementById('alertDetails');
alertDetails.innerHTML = `
  <div class="pest-alert-box">
    <strong>⚠ Pest Alert Details:</strong>
    <ul></ul>
  </div>
`;

const list = alertDetails.querySelector('ul');

data.forEach(field => {
  if (field.pest_infestation_rate > 20) {
    const li = document.createElement('li');
    li.innerHTML = `<strong>${field.field_name}</strong>: ${field.pest_infestation_rate}% infestation`;
    list.appendChild(li);
  }
});

  })
  .catch(error => console.error('Error loading pest data:', error));

</script>


<script src="https://cdn.botpress.cloud/webchat/v2.3/inject.js"></script>
<script src="https://files.bpcontent.cloud/2025/04/24/14/20250424142333-K2CYE6P6.js"></script>
</body>
</html>
